package curriculum_B;

public class Employee {
	
// 基本概念
	String name;
	// name（文字列型）フィールド
	public void work() {
		// work() メソッド
		System.out.println(name + "は働いています。");
		// [name]は働いています。 と出力
	}
	
// クラスとオブジェクト
    String employeeId;
    // 社員ID
    public void showInfo() {
    	System.out.println("社員ID:" + employeeId + ",名前:" + name);
    }
    
// カプセル化
    private String employeeId;
    private String name;
    
    
    
		
		
		

		// TODO Auto-generated method stub


}
