package curriculum_B;

public class Greeting {

	// Q4
	public void sayHello() {
		System.out.println("こんにちは！");
	}
}
// TODO Auto-generated method stub 
