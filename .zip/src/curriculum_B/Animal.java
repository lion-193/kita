package curriculum_B;

public class Animal {

	// Q5
	private String name;
	private String height;
	private String speed;
	// フィールド（変数）

	public String getName() {
		return name;
	}
	// nameのgetterとsetter 

	public void setName(String name) {
		this.name = name;
	}
	// thisで自分のnameに代入

	public String getHeight() {
		return height;
	}
	// heightのgetterとsetter

	public void setHeight(String height) {
		this.height = height;
	}
	// thisで自分のheightに代入

	public String getSpeed() {
		return speed;
	}
	// speedのgetterとsetter

	public void setSpeed(String speed) {
		this.speed = speed;
	}
	// thisで自分のspeedに代入
}
//TODO Auto-generated method stub